---
layout: layouts/default.ejs
---

### **To contact me, here are some links to my socials**

---

- #### [LinkedIn](https://www.linkedin.com/in/drashyapatel)
- #### **Email**: drashya.patel1@dcmail.ca
- #### **MicrosoftTeams**: drashya.patel1@dcmail.ca
- #### **Discord Username**: heyitz_dp 
- #### [Instagram](https://www.instagram.com/callmedrashya/)
